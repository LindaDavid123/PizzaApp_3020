<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Account_model extends CI_Model {

	function __construct() {
		parent::__construct();
		$this->load->database();
	}

	public function login($username, $password)
	{
		return $this->db->get_where('account', array('username' => $username, 'password' => $password))->row_array();
	}
}
